#include <stdio.h>
#include <stdlib.h>
int main(void) {
    int alunos_turma_a = 0;
    int alunos_turma_b = 0;
    float acumulador_turma_a = 0;
    float acumulador_turma_b = 0;
    printf("TURMA A\n");
    printf("Digite a quantidade de alunos ");
    scanf("%d",&alunos_turma_a);
    float *notas;
    notas = (float*)  malloc(alunos_turma_a * sizeof(float));
    for(int i = 0;i < alunos_turma_a;i++){
      printf("\nDigite a nota do aluno %d\n",i+1);
      scanf("%f",&notas[i]);
      printf("notas %1f\n",notas[i]);
      acumulador_turma_a +=  + notas[i];
      
    }
    printf("\nTURMA B\n");
    printf("Digite a quantidade de alunos ");
    scanf("%d",&alunos_turma_b);
    notas = (float*) realloc(notas, alunos_turma_b * sizeof(float));
    for(int i = 0;i < alunos_turma_b;i++){
      printf("\nDigite a nota do aluno %d\n",i+1);
      scanf("%1f",&notas[i]);
      printf("notas %f\n",notas[i]);
      acumulador_turma_b +=  + notas[i];
      
    }
    float resultado_turma_a = acumulador_turma_a / alunos_turma_a;
    float resultado_turma_b = acumulador_turma_b / alunos_turma_b;
    printf("a media da turma A %1f\n",resultado_turma_a);
    printf("a media da turma B %1f\n",resultado_turma_b);
    free(notas);
    return 0;
    
}