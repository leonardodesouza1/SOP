#include <stdio.h>
#include<stdlib.h>

int main(void) {
  FILE *produtos = fopen("produtos.txt","a");
  char codigo[4];
  char nome[100];
  char valor[100];

  printf("Digite o codigo do produto[3 caracter]: ");
  scanf("%s",codigo);
  printf("Digite o nome do produto: ");
  scanf("%s",nome);
  printf("Digite o valor do produto:  ");
  scanf("%s",valor);
  fprintf(produtos , "%s %s %s \n",codigo,nome,valor);
  fclose(produtos);
  return 0;
}