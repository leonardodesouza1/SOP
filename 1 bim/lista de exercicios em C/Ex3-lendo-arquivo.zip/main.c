#include <stdio.h>
#include<stdlib.h>

int main(void) {
  FILE *produtos = fopen("produtos.txt","r");
  char linha[100];
   while (fgets(linha, 100, produtos) != NULL)
   {
        printf("%s", linha);
   }
  fclose(produtos);
  return 0;
}