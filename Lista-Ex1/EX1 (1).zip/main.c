#include <stdio.h>
float media(float n1, float n2){
  float resultado;
  resultado = n1/n2;
  return(resultado);
}

int main(void) {
    for (int i = 0;i <= 1;i++){
    printf("\nTURMA %d\n",i+1);
    printf("Digite a quantidade de alunos ");
    int alunos = 0;
    float acumulador = 0;
    scanf("%d",&alunos);
    printf("quantidade de alunos = %d",alunos);
    float notas[alunos];
    int j = 0;
    for(j = 0;j < alunos;j++){
      printf("\nDigite a nota do aluno %d\n",j+1);
      scanf("%f",&notas[j]);
      printf("notas %f\n",notas[j]);
      acumulador = acumulador + notas[j];
      printf("acumulador %f\n",acumulador);
    }

    float resultado = media(acumulador,alunos);
    printf("a media da turma e %1f\n",resultado);
    }
    return 0;
    
}